#include "amxxmodule.h"
#include "Header.h"

static INT g_TeamInfo = (INT)0xFFFFFFF;

CHAR IsPlayer(INT Player)
{
	return Player < (INT)1U || Player > (INT)gpGlobals->maxClients ? CHAR(FALSE) : CHAR(TRUE);
}

CHAR IsPlayerSafe(INT Player)
{
	return MF_IsPlayerIngame((INT)Player) ? CHAR(TRUE) : CHAR(FALSE);
}

static cell AMX_NATIVE_CALL CSSetTeam(AMX * Handle, cell * Parameter)
{
	static edict_t * Entity = NULL;
	static INT Player = 0U;
	static CHAR Team = CHAR(0U);

	Player = INT(Parameter[1U]);
	Team = CHAR(Parameter[2U]);

	if (g_TeamInfo == 0xFFFFFFF)
	{
		g_TeamInfo = GET_USER_MSG_ID(PLID, "TeamInfo", NULL);

		if (g_TeamInfo == 0xFFFFFFF)
		{
			MF_LogError(Handle, AMX_ERR_NATIVE, "Unable to reach TeamInfo message!");

			return 0U;
		}
	}

	else if (!IsPlayer(Player))
	{
		MF_LogError(Handle, AMX_ERR_NATIVE, "Player %d is not valid!", (INT)Player);

		return 0U;
	}

	else if (!IsPlayerSafe(Player))
	{
		MF_LogError(Handle, AMX_ERR_NATIVE, "Cannot access player %d, it's not safe enough!", (INT)Player);

		return 0U;
	}

	Entity = MF_GetPlayerEdict(Player);

	*((PINT)Entity->pvPrivateData + CSTeamOffset) = INT(Team);

	MESSAGE_BEGIN(MSG_BROADCAST, (INT)g_TeamInfo);
	WRITE_BYTE(Player);

	switch (Team)
	{
	case CSTEAM_UNASSIGNED:
		MF_SetPlayerTeamInfo(Player, Team, NULL);

		WRITE_STRING("UNASSIGNED");

		break;

	case CSTEAM_TERRORIST:
		MF_SetPlayerTeamInfo(Player, Team, "TERRORIST");

		WRITE_STRING("TERRORIST");

		break;

	case CSTEAM_CT:
		MF_SetPlayerTeamInfo(Player, Team, "CT");

		WRITE_STRING("CT");

		break;

	case CSTEAM_SPECTATOR:
		MF_SetPlayerTeamInfo(Player, Team, NULL);

		WRITE_STRING("SPECTATOR");

		break;
	}

	MESSAGE_END();

	return 1U;
}

static cell AMX_NATIVE_CALL CSSetTeamIndex(AMX * Handle, cell * Parameter)
{
	static INT Player = 0U;
	static CHAR Team = 0U;

	Player = Parameter[1U];
	Team = CHAR(Parameter[2U]);

	if (!IsPlayer(Player))
	{
		MF_LogError(Handle, AMX_ERR_NATIVE, "Player %d is not valid!", (INT)Player);

		return 0U;
	}

	else if (!IsPlayerSafe(Player))
	{
		MF_LogError(Handle, AMX_ERR_NATIVE, "Cannot access player %d, it's not safe enough!", (INT)Player);

		return 0U;
	}

	switch (Team)
	{
	case CSTEAM_TERRORIST:
		MF_SetPlayerTeamInfo(Player, Team, "TERRORIST");

		break;

	case CSTEAM_CT:
		MF_SetPlayerTeamInfo(Player, Team, "CT");

		break;

	default:
		MF_SetPlayerTeamInfo(Player, Team, NULL);

		break;
	}

	return 1U;
}

static cell AMX_NATIVE_CALL CSSetTeamOffset(AMX * Handle, cell * Parameter)
{
	static edict_t * Entity = NULL;
	static INT Player = 0U;
	static CHAR Team = 0U;

	Player = Parameter[1U];
	Team = CHAR(Parameter[2U]);

	if (!IsPlayer(Player))
	{
		MF_LogError(Handle, AMX_ERR_NATIVE, "Player %d is not valid!", (INT)Player);

		return 0U;
	}

	else if (!IsPlayerSafe(Player))
	{
		MF_LogError(Handle, AMX_ERR_NATIVE, "Cannot access player %d, it's not safe enough!", (INT)Player);

		return 0U;
	}

	Entity = MF_GetPlayerEdict(Player);

	*((PINT)Entity->pvPrivateData + CSTeamOffset) = (INT)Team;

	return 1U;
}

static cell AMX_NATIVE_CALL CSSetTeamScoresTable(AMX * Handle, cell * Parameter)
{
	static INT Player = 0U;
	static CHAR Team = 0U;

	Player = Parameter[1U];
	Team = (CHAR)Parameter[2U];

	if (g_TeamInfo == 0xFFFFFFF)
	{
		g_TeamInfo = GET_USER_MSG_ID(PLID, "TeamInfo", NULL);

		if (g_TeamInfo == 0xFFFFFFF)
		{
			MF_LogError(Handle, AMX_ERR_NATIVE, "Unable to reach TeamInfo message!");

			return 0U;
		}
	}

	else if (!IsPlayer(Player))
	{
		MF_LogError(Handle, AMX_ERR_NATIVE, "Player %d is not valid!", (INT)Player);

		return 0U;
	}

	else if (!IsPlayerSafe(Player))
	{
		MF_LogError(Handle, AMX_ERR_NATIVE, "Cannot access player %d, it's not safe enough!", (INT)Player);

		return 0U;
	}

	MESSAGE_BEGIN(MSG_BROADCAST, (INT)g_TeamInfo);
	WRITE_BYTE(Player);

	switch (Team)
	{
	case CSTEAM_UNASSIGNED:
		WRITE_STRING("UNASSIGNED");

		break;

	case CSTEAM_TERRORIST:
		WRITE_STRING("TERRORIST");

		break;

	case CSTEAM_CT:
		WRITE_STRING("CT");

		break;

	case CSTEAM_SPECTATOR:
		WRITE_STRING("SPECTATOR");

		break;
	}

	MESSAGE_END();

	return 1U;
}

CONST AMX_NATIVE_INFO g_CSTeamChangerFunctions[] =
{
	{ "cs_set_team", CSSetTeam },
	{ "cs_set_team_id", CSSetTeamIndex },
	{ "cs_set_team_offset", CSSetTeamOffset },
	{ "cs_set_team_tablescore", CSSetTeamScoresTable },

	{ NULL, NULL }
};

VOID OnAmxxAttach(VOID)
{
	MF_AddNatives(g_CSTeamChangerFunctions);
}

BOOL AmxxCheckGame(CONST CHAR * Game)
{
	if (!_stricmp(Game, "CStrike") || !_stricmp(Game, "CZero"))
	{
		return AMXX_GAME_OK;
	}

	return AMXX_GAME_BAD;
}

INT RegUserMsg_Post(CONST CHAR * Name, INT)
{
	if (!_stricmp(Name, "TeamInfo"))
	{
		g_TeamInfo = (INT)META_RESULT_ORIG_RET(INT);
	}

	RETURN_META_VALUE(MRES_IGNORED, (INT)0U);
}
