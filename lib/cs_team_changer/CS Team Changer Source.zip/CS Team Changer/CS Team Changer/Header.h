#if !defined HEADER_H

#define HEADER_H

#include "amxxmodule.h"

#define CONST const
#define INT int
#define CHAR char
#define _stricmp strcasecmp
#define VOID void
#define PINT int*

enum CSGameOffset
{
#if defined __linux__
	CSExtraOffset = 5U,
#else
	CSExtraOffset = 0U,
#endif

	CSTeamOffset = 114U + CSExtraOffset
};

enum CSTeam
{
	CSTEAM_UNASSIGNED = 0U,
	CSTEAM_TERRORIST = 1U,
	CSTEAM_CT = 2U,
	CSTEAM_SPECTATOR = 3U
};

BOOL AmxxCheckGame(CONST CHAR * Game);
VOID OnAmxxAttach(VOID);

#endif
